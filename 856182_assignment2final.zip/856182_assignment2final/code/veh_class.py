import numpy as np
np.set_printoptions(threshold='nan')
import matplotlib.pyplot as pl
from PIL import Image, ImageDraw
import random

def im2feature(I):
    """
    returns a d-dimensional feature vector v computed on a 2D boundary image I
    """
    basewidth = 300
    hsize = 150
    I = I.resize((basewidth, hsize))
    features = []
    for i in range(2):
        for j in range(6):
            features.append(get_gradient(I, j*50, i*75))
 
    return np.array(features)


def get_gradient(img, x, y):
    Xx = []
    Yy = []
    for i in range(x, x+50):
        for j in range(y, y+75):
            r, g, b = img.getpixel((i, j))
            if r+b+g == 0:
                Xx.append(i)
                Yy.append(j)
    Xx = np.asarray(Xx)
    Yy = np.asarray(Yy)
    z = np.polyfit(Xx, Yy, 1)
    
    return z[0]


def load_data():
    """
    loads training and testing data
    """
    # training data
    loc = '../data/train/'
    cls = ['Class1', 'Class2']
    x_training = np.zeros((30, 12), dtype=np.float)
    y_training = np.zeros((30, 1), dtype=np.float)
    k = 0
    for c in np.arange(0, len(cls)):
        for s in np.arange(1, 16):
            I = Image.open(loc + cls[c] + '_Sample' + str(s) + '.png').convert("RGB")
            v = im2feature(I)
            x_training[k,:] = v.T
            y_training[k,0] = 2.0*c - 1
            k = k + 1
    # add all one column to the first axis
    x_training = np.hstack((np.ones((x_training.shape[0],1)), x_training))

    # testing data
    loc = '../data/test/'
    cls = ['Class1', 'Class2']
    x_testing = np.zeros((30, 12), dtype=np.float)
    y_testing = np.zeros((30, 1), dtype=np.float)
    k = 0
    for c in np.arange(0, len(cls)):
        for s in np.arange(1, 16):
            I = Image.open(loc + cls[c] + '_Sample' + str(s) + '.png').convert("RGB")
            v = im2feature(I)
            x_testing[k,:] = v.T
            y_testing[k,0] = 2.0*c - 1
            k = k + 1
    # add all one column to the first axis
    x_testing = np.hstack((np.ones((x_testing.shape[0],1)), x_testing))
    return x_training, y_training, x_testing, y_testing

def normalization_parameters(x):
    """
    computes and returns normalization parameters (mean and std vectors of each
    column) from data x where it is assumed that the very first column is all
    1s
    """
    mean_vector = np.mean(x, axis=0)
    mean_vector[0] = 0
    std_vector = np.std(x, axis=0)
    std_vector[0] = 1.0
    return mean_vector, std_vector

def normalize_data(x, mean_vector, std_vector):
    """
    normalizes the input data x by parameters mean_vector and std_vector
    """
    x = x - mean_vector
    x = x / std_vector
    return x

def KNN(x_training, y_training, x_testing, K):
    """
    returns the class label for x_testing considering K nearest neighbours
    on training data (x_training, y_training)
    """
    d = np.sqrt(np.sum((x_training - x_testing)**2, axis=1))
    i = np.argsort(d)
    s = np.sum(y_training[i[np.arange(K)],:])
    l = (s > 0.0) * 1.0 + (s<=0.0) * -1.0
    return l
    
def scatterpl(x_training, p):
	#p = [p[i] + 3 for i in range(len(p))]
	p = [('y' if p[i] == 1 else 'r') for i in range(len(p))]
	for i in range(1, 13):
		for j in range(i, 13):
			X = [w[i] for w in x_training ]
			Y = [w[j] for w in x_training ]
			pl.scatter(X, Y, c = p)
			#pl.plot(np.unique(X),np.poly1d(np.polyfit(X,Y,1))(np.unique(X)))
			pl.savefig("%d %d.png"%(i,j))
			pl.clf()
            
def KNN_learn(x_training, y_training):
    """
    returns the optimum parameter for KNN classifier using hold-out cross
    validation on training data. you can split training data into two disjoint
    sets to perform hold-out cross validation.
    """
    random.seed(42)
    indexarr = list(range(30))
    random.shuffle(indexarr)
    x_training1 = x_training[indexarr[:15],:]
    x_validation = x_training[indexarr[15:],:]
    #print(x_training)
    #print(x_validation)
    y_training1 = y_training[indexarr[:15],:]
    y_validation = y_training[indexarr[15:],:]
    #arr = []
    err = [1.0]*len(x_training1)
    K = 1
    for K in range(1, len(x_training1)):
        err[K] = KNN_error(K, x_training1, y_training1, x_validation, y_validation)
        #arr.append(err[K])
        if err[K] - err[K-1] > 0.0:
            #print(err)
            return K-1
        if err[K] == 0.0:
            #print(err)
            return K
    return K

    #K = 1
    #return K

def LR(Theta, x_testing):
    """
    Theta: parameters of logistic regression type classifier
    x_testing: test data
    returns the class label of x_testing using logistic regression type classifier
    """
    h = 1.0 / (1.0 + np.exp(-np.dot(x_testing, Theta)))
    l = (h >= 0.5) * 1.0 + (h < 0.5) * (-1.0)
    return l




def LR_learn(x_training, y_training):
    """
    returns the parameters Theta of logistic regression type classifier
    """

    alpha = 0.1
    theta = np.zeros((x_training.shape[1], 1), dtype=np.float)
    #y = h(x_training, theta)
    t = 1
    while True:

        y = LR(theta, x_training)
        e = y - y_training

        o = x_training * e
        p = np.mean(o, axis=0)

        theta_previous = theta.copy()
        theta = theta - alpha * p[:, np.newaxis]

        if np.max(np.abs(theta - theta_previous)) < 1e-3:
            break

        t = t +1
    return theta

def LR_error(Theta, x_testing, y_testing):
    """
    returns empirical error of logistic regression type classifier on
    (x_testing, y_testing)
    """
    h = LR(Theta, x_testing)
    e = np.sum(h!=y_testing)
    e = e / np.float(y_testing.shape[0])
    return e

def KNN_error(K, x_training, y_training, x_testing, y_testing):
    h = np.zeros((x_testing.shape[0], 1))
    for n in np.arange(0, x_testing.shape[0]):
        h[n,0] = KNN(x_training, y_training, x_testing[n,:], K)
    e = np.sum(h!=y_testing)
    e = e / np.float(y_testing.shape[0])
    return e


# load training and testing data
x_training, y_training, x_testing, y_testing = load_data()

# normalize training and testing data
mean_vector, std_vector = normalization_parameters(x_training)
x_training = normalize_data(x_training, mean_vector, std_vector)
x_testing = normalize_data(x_testing, mean_vector, std_vector)

scatterpl(x_training, y_training)
# learn parameters for KNN and LR
K = KNN_learn(x_training, y_training)
Theta = LR_learn(x_training, y_training)

# Compute training error rates for KNN and Logistic Regression
e = KNN_error(K, x_training, y_training, x_training, y_training)
print('{:d}NN empirical train eror: {:.2f}'.format(K, e))

e = LR_error(Theta, x_training, y_training)
print('Logistic Regression empirical train error: {:.2f}'.format(e))


# Compute testing error rates for KNN and Logistic Regression
e = KNN_error(K, x_training, y_training, x_testing, y_testing)
print('{:d}NN empirical test eror: {:.2f}'.format(K, e))

e = LR_error(Theta, x_testing, y_testing)
print('Logistic Regression empirical test error: {:.2f}'.format(e))




