#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 20 19:54:10 2018

@author: primrose
"""
import numpy as np

def KNN(x_training, y_training, x_testing, K):
    """
    returns the class label for x_testing considering K nearest neighbours
    on training data (x_training, y_training)
    """
    d = np.sqrt(np.sum((x_training - x_testing)**2, axis=1))
    i = np.argsort(d)
    s = np.sum(y_training[i[np.arange(K)],:])
    l = (s > 0.0) * 1.0 + (s<=0.0) * -1.0
    d = d[i]
    print(d)
    #print('distance', d[:K])
    #print('record', i[:K])
    y = y_training[i]; #print('label', y[:K])
    #print('target', l)
    return l
    
def KNN_error(K, x_training, y_training, x_testing, y_testing):
    h = np.zeros((x_testing.shape[0], 1))
    for n in np.arange(0, x_testing.shape[0]):
        h[n,0] = KNN(x_training, y_training, x_testing[n,:], K)
    e = np.sum(h!=y_testing)
    e = e / np.float(y_testing.shape[0])
    #print e
    return e
    
first = np.loadtxt("banknote_training_data.txt", delimiter = ",")
second = np.loadtxt("banknote_testing_data.txt", delimiter = ",") 
x_training = first[:,:-1]
y_training = first[:,-1]
x_training = x_training
y_training = np.transpose([y_training])
x_training = np.hstack((np.ones((x_training.shape[0],1)), x_training))
x_testing = second[:,:-1]
y_testing = second[:,-1]
y_testing = np.transpose([y_testing])
x_testing = np.hstack((np.ones((x_testing.shape[0],1)), x_testing))


x_q11 = [1.0, 3.618100, -3.745400, 2.827300, -0.712080]
x_q13 = [1.0, -2.436500, 3.602600, -1.416600, -2.894800]
x_q15 = [1.0, -4.366700, 6.069200, 0.572080, -5.466800]
#five = KNN(x_training, y_training, x_q15, 5)

#KNN_error(3, x_training, y_training, x_testing, y_testing)
#three = KNN(x_training, y_training, x_q12, 3)
#one = KNN(x_training, y_training, x_q11, 1)
#print(one)
#print(x_training.shape)
#print(y_training.shape)
#KNN(x_training, y_training, 
#print (x_training)
#print (y_training)
one = KNN_error(1, x_training, y_training, x_testing, y_testing)  
third = KNN_error(3, x_training, y_training, x_testing, y_testing)  
fifth = KNN_error(5, x_training, y_training, x_testing, y_testing)   
#print(one)
#print(third)
#print(fifth)
theta = np.transpose([np.array([1.47791190, -1.55084741, -0.89930302, -0.91395829, -0.14429827])])
def h(x,theta, n, beta=1.0):
    o = np.dot(x, theta)
    h = 2 * (1.0/(1+np.exp((-o)*beta))) - 1
    l = (h >= 0.0)*1 + (h < 0.0)*-1
    print("%d\t%f\t%d" % (n, h, l))

for n in range(5, 41, 5):
    h(x_testing[n-1], theta, n)
   
#print(first)
#print(second)    
    
