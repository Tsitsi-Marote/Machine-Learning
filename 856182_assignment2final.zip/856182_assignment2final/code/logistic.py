def learn(x_training, y_training, theta, alpha=0.1): #alpha is learning rate
    t = 1
    while True:
        
        y = h(x_training, theta)
        e = y - y_training
        
        
        o = x_training * e
        p = np.mean(o, axis=0) #0 is the row axis, take mean along the row
       
        theta_previous = theta.copy()
        theta = theta - alpha * p[:, np.newaxis]
      
        if np.max(np.abs(theta - theta_previous)) < 1e-3:
            break;
       
        t = t +1
    return theta    
            
